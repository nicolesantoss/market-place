package com.example.projetoA3crud;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Nicole
 */

@Entity //relacionar o modelo com o banco de dados
@Table(name = "usuario") //dados armazenados na tabela "user"

public class Usuario {

    @Id

    @GeneratedValue(strategy = GenerationType.IDENTITY) //cada elemento da tabela possui um id único e gerado automaticamente

    private Long id;

    @Column

    private String nome;
    
    //getters e setters para os atributos da tabela
    public Long getId() {
    return id;
    }

    public void setId(Long id) {
    this.id = id;
    }

    public String getNome() {
    return nome;
    }

    public void setNome(String nome) {
    this.nome = nome;
    }
}    
