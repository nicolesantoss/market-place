package com.example.projetoA3crud;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Nicole
 */

//controlador, onde cada um dos endpoints serão criados

    @RestController
    public class RestcrudController {

    @Autowired
    private UsuarioRepository repositorioUsuario;

    @GetMapping("/usuarios") //listar todos os usuários do banco de dados (endpoint do tipo get)
    public Iterable<Usuario> listarTodosUsuarios() {

    // Implementação
    return repositorioUsuario.findAll(); //findAll é um método do CrudRepository que retorna todos os elementos em uma tabela
    }

    @GetMapping("/usuario/{id}") //listar somente um usuário do banco de dados (endpoint do tipo get)
    public ResponseEntity<Usuario> buscarUsuarioPorId(@PathVariable long id) {

    // Implementação
    Optional<Usuario> usuario = repositorioUsuario.findById(id);
    if (usuario.isPresent()) {
        return ResponseEntity.ok().body(usuario.get());
    }else {
        return ResponseEntity.notFound().build();
    }
    }

    @PostMapping("/novousuario") //adicionar um usuário no banco de dados (endpoint do tipo post)
    public Usuario salvarUsuario(@Validated @RequestBody Usuario usuario) {

    // Implementação
    return repositorioUsuario.save(usuario);
    }
}

