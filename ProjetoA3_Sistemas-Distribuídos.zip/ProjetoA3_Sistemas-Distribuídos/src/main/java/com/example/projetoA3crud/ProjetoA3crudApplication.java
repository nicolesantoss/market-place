package com.example.projetoA3crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoA3crudApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoA3crudApplication.class, args);
	}

}
