package com.example.projetoA3crud;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author Nicole
 */
// fornecer a página index.html
@Controller
public class WebController {
// A página index.html será mostrada

    @RequestMapping("market-place")
    public String index() {

        return "index";
    }
    
    @RequestMapping("/login")
    public String indexlog() {

        return "indexlog";
    }
    
    @RequestMapping("/cadastro")
    public String indexcad() {

        return "indexcad";
    }
    
}
