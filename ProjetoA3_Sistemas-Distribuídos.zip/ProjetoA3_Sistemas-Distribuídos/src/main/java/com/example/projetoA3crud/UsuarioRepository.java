package com.example.projetoA3crud;

import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author Nicole
 */
    //repositório para Usuario, para realizar operações CRUD em uma entidade Usuario
    public interface UsuarioRepository extends CrudRepository<Usuario, Long>{
    
    }

