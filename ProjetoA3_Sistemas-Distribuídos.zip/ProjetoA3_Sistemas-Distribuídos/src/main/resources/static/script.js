function verificarLogin() {
    // Obtendo os valores dos campos do formulário de login
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Obtendo os dados salvos do localStorage
    const savedUserData = localStorage.getItem('userData');
    const userData = JSON.parse(savedUserData);

    // Verificando se os dados correspondem
    if (email === userData.email && password === userData.password) {
      // Login bem-sucedido
      // Redirecionar o usuário para a página inicial Market-Place
      alert('Login bem-sucedido! Redirecionando...');
      window.location.href = 'localhost:8080/market-place';
    } else {
      // Login inválido
      // Mensagem de erro
      alert('Login inválido! Por favor, verifique seus dados ou cadastre-se.');
    }
}

// Alternar entre o modo claro e escuro
// Adiciona um ouvinte de eventos ao elemento com o id 'mode_icon'
document.addEventListener("DOMContentLoaded", function() {
  const mode = document.getElementById('mode_icon');

mode.addEventListener('click', () => {
    const form = document.getElementById('login_form');

    if(mode.classList.contains('fa-moon')) {
        mode.classList.remove('fa-moon');
        mode.classList.add('fa-sun');

        form.classList.add('dark');
        return ;
    }
    
    mode.classList.remove('fa-sun');
    mode.classList.add('fa-moon');

    form.classList.remove('dark');

});
});

/*const mode = document.getElementById('mode_icon');

mode.addEventListener('click', () => {
    const form = document.getElementById('login_form');

    if(mode.classList.contains('fa-moon')) {
        mode.classList.remove('fa-moon');
        mode.classList.add('fa-sun');

        form.classList.add('dark');
        return ;
    }
    
    mode.classList.remove('fa-sun');
    mode.classList.add('fa-moon');

    form.classList.remove('dark');
});*/


