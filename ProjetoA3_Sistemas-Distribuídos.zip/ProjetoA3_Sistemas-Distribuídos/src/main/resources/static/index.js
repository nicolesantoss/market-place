// Alternar entre o modo claro e modo escuro
document.addEventListener("DOMContentLoaded", function() {
  const botaoAlterarTema = document.getElementById("botao_alterar_tema");
  const body = document.querySelector("body");
  const imagemBotaoTrocaDeTema = document.querySelector(".imagem-sol-botao");

  botaoAlterarTema.addEventListener("click", () => {
    const modoEscuroEstaAtivo = body.classList.contains("modo_escuro");

    body.classList.toggle("modo_escuro");

    if (modoEscuroEstaAtivo) {
      imagemBotaoTrocaDeTema.setAttribute("src", "sol.png");
    } else {
      imagemBotaoTrocaDeTema.setAttribute("src", "lua.png");
    }
  });

  const mode = document.getElementById('mode_icon');

  mode.addEventListener('click', () => {
    const form = document.getElementById('login_form');

    if(mode.classList.contains('fa-moon')) {
      mode.classList.remove('fa-moon');
      mode.classList.add('fa-sun');

      form.classList.add('dark');
      return ;
    }
    
    mode.classList.remove('fa-sun');
    mode.classList.add('fa-moon');

    form.classList.remove('dark');
  });
});

// Redirecionar para a página do produto
function redirecionarParaComprarLeite() {
    window.location.href = "https://www.paodeacucar.com/produto/176191?storeId=501&isGoogleShopping=true&utm_source=Bing&utm_medium=Shopping&utm_campaign=pda-shopping-despensa-sp&msclkid=8f17c4a1646c1b21077ba0274d6b918e"; 
}
function redirecionarParaComprarAcucar(){
    window.location.href = "https://www.paodeacucar.com/produto/74215?storeId=501&isGoogleShopping=true&utm_source=Bing&utm_medium=Shopping&utm_campaign=pda-shopping-despensa-sp&msclkid=b7628faca1f71b8c08e4eb2a8abc19b6";
}
function redirecionarParaComprarCafe(){
    window.location.href = "https://www.paodeacucar.com/produto/90515/cafe-pilao-torrado-e-moido-tradicional-vacuo-500g";
}
function redirecionarParaComprarArroz(){
    window.location.href = "https://www.paodeacucar.com/produto/99080?storeId=501&isGoogleShopping=true&utm_source=Bing&utm_medium=Shopping&utm_campaign=pda-shopping-despensa-sp&msclkid=18e0796f6f0012d899ff1de94315d21c";
}
function redirecionarParaComprarOleo(){
    window.location.href = "https://www.paodeacucar.com/produto/131661/oleo-de-soja-liza-pet-900ml";
}
function redirecionarParaComprarMacarrao(){
    window.location.href = "https://www.paodeacucar.com/produto/152221?storeId=501&isGoogleShopping=true&utm_source=Bing&utm_medium=Shopping&utm_campaign=pda-shopping-despensa-sp&msclkid=2907b75778a91d2cb80dd3d15408d1ea";
}
function redirecionarParaComprarCremeLeite(){
    window.location.href = "https://www.paodeacucar.com/produto/96606/creme-de-leite-italac-caixa-200g";
}
function redirecionarParaComprarAzeite(){
    window.location.href = "https://www.paodeacucar.com/produto/100849/azeite-de-oliva-extra-virgem-classico-portugues-gallo-vidro-500ml";
}
function redirecionarParaComprarFeijao(){
    window.location.href = "https://www.paodeacucar.com/produto/9461/feijao-carioca-tipo-1-camil-pacote-1kg";
}
function redirecionarParaComprarCarne(){
    window.location.href = "https://www.swift.com.br/carne-moida-patinho-swift-900g/p";
}
function redirecionarParaComprarAmaciante(){
    window.location.href = "https://www.paodeacucar.com/produto/315604/amaciante-concentrado-downy-brisa-de-verao-1l";
}
function redirecionarParaComprarLimpaVidros(){
    window.location.href = "https://www.paodeacucar.com/produto/331441/limpa-vidros-spray-veja-vidrex-cristal-500ml-oferta";
}
function redirecionarParaComprarTiraManchas(){
    window.location.href = "https://www.paodeacucar.com/produto/165618/tira-manchas-em-po-vanish-multi-power-oxi-action-450g-para-roupas-coloridas";
}
function redirecionarParaComprarSabaoPo(){
    window.location.href = "https://www.paodeacucar.com/produto/1326869/lava-roupas-po-roupas-brancas-e-coloridas-brilhante-limpeza-total-pacote-800g";
}
function redirecionarParaComprarDetergente(){
    window.location.href = "https://www.paodeacucar.com/produto/57982/detergente-liquido-ype-neutro-500ml";
}