function salvarDados(event) {
    // Obtendo os valores dos campos do formulário de cadastro
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const telefone = document.getElementById('telefone').value;
    const feminino = document.getElementById('feminino').checked;
    const masculino = document.getElementById('masculino').checked;
    const outro = document.getElementById('outro').checked;
    const data_nascimento = document.getElementById('data_nascimento').value;
    const cidade = document.getElementById('cidade').value;
    const estado = document.getElementById('estado').value;
    const endereco = document.getElementById('endereco').value;
            
    // Selecionar o formulário de cadastro
    const formCadastro = document.getElementById('cadastro_form');
    // Adicionar um ouvinte de evento para o evento de envio do formulário
    formCadastro.addEventListener('submit', salvarDados);

    // Criando um objeto com os dados de cadastro
    const userData = {
        nome: nome,
        email: email,
        password: password,
        telefone: telefone,
        feminino: feminino,
        masculino: masculino,
        outro: outro,
        data_nascimento: data_nascimento,
        cidade: cidade,
        estado: estado,
        endereco: endereco
        };

    // Armazenando os dados no localStorage
    localStorage.setItem('userData', JSON.stringify(userData));

    // Exibindo uma mensagem de sucesso
    alert('Cadastro realizado com sucesso!');

    // Redirecionando o usuário para a página de login
    window.location.href = 'http://localhost:8080/login';
    }

function verificarLogin() {
    // Obtendo os valores dos campos do formulário de login
    const email = document.getElementById('email').value;
    const password = document.getElementById('passowrd').value;

    // Obtendo os dados salvos do localStorage
    const savedUserData = localStorage.getItem('userData');
    const userData = JSON.parse(savedUserData);

    // Verificando se os dados correspondem
    if (email === userData.email && password === userData.password) {
      // Login bem-sucedido
      // Redirecionando o usuário para a página de login
    alert('Login bem-sucedido! Redirecionando...');
    window.location.href = 'https://localhost:8080/login';
    } else {
      // Login inválido
      // Mensagem de erro
    alert('Login inválido! Por favor, verifique seus dados ou cadastre-se.');
    }
}