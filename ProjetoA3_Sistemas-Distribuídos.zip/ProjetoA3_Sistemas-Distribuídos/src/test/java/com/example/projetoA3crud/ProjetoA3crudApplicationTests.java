package com.example.projetoA3crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoA3crudApplicationTests {

	@Test
	void contextLoads() {
	}

}
